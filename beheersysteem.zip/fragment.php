<?php include 'includes/header.php'; ?>
<body id="fragment">
	<?php include 'includes/sidebar.php'; ?>
	<div class="content">
		<div class="top">
			<div class="title">
				<i class="fas fa-plus"></i>
				<h2>Fragment toevoegen</h2>
			</div>
			<div class="account">
				<i class="far fa-user"></i>
				<span>Account</span>
			</div>
		</div>
		<div class="account-menu">
			<nav>
				<ul>
					<li><a href="handout_calamiteiten.pdf" target="_blank"><i class="fas fa-exclamation-triangle"></i>Calamiteiten</a></li>
					<li><a href="contact.php"><i class="fas fa-envelope"></i>Contact</a></li>
					<li class="logout"><a href="index.php"><i class="fas fa-sign-out-alt"></i>Uitloggen</a></li>
				</ul>
			</nav>
		</div>
		<main class="animsition">

			<div class="fragments">
				<div class="top-bar">
					<label>
						<p>Categorieën</p>
						<select>
				 			<option class="placeholder" disabled selected value>Laat alle categorieën zien</option>
						  <option>Widgets</option>
						  <option>Afbeelding</option>
						  <option>Video</option>
						</select>
					</label>
					<label>
						<p>Selecteer richting</p>
						<select>
					 		<option class="placeholder" disabled selected value>Alle richtingen</option>
						  <option>Horizontaal</option>
						  <option>Verticaal</option>
						</select>
					</label>
				</div>
				<div class="all-fragments">

					<a class="fragment" id="custom">
						<i class="fas fa-plus"></i><span>Maak eigen fragment</span>
					</a>

					<div class="fragment" id="image">
						<i class="far fa-image"></i><span>Voeg afbeelding toe</span>
					</div>

					<div class="fragment" id="video">
						<i class="fas fa-video"></i><span>Voeg video toe</span>
					</div>

					<div class="fragment" id="ns">
						<div class="top">
							<a class="preview" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=564">
								<i class="fas fa-search"></i>
							</a>
						</div>

						<a data-fancybox data-src="#ns-fragment" href="javascript:;" class="add-fragment">
							<i class="fas fa-plus"></i><span>Toevoegen</span>
						</a>

						<div class="bottom">
							<h3>NS</h3>
						</div>
					</div>

					<div class="fragment" id="buienradar">
						<div class="top">
							<a class="preview" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=550">
								<i class="fas fa-search"></i>
							</a>
						</div>
						<a data-fancybox data-src="#buienradar-fragment" href="javascript:;" class="add-fragment">
							<i class="fas fa-plus"></i><span>Toevoegen</span>
						</a>
						<div class="bottom">
							<h3>Buienradar</h3>
						</div>
					</div>
					<div class="fragment" id="bbc">
						<div class="top">
							<a class="preview" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=555">
								<i class="fas fa-search"></i>
							</a>
						</div>
						<a data-fancybox data-src="#bbc-fragment" href="javascript:;" class="add-fragment">
							<i class="fas fa-plus"></i><span>Toevoegen</span>
						</a>
						<div class="bottom">
							<h3>BBC</h3>
						</div>
					</div>
					<div class="fragment" id="nu">
						<div class="top">
							<a class="preview" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=552">
								<i class="fas fa-search"></i>
							</a>
						</div>
						<a data-fancybox data-src="#nu-fragment" href="javascript:;" class="add-fragment">
							<i class="fas fa-plus"></i><span>Toevoegen</span>
						</a>
						<div class="bottom">
							<h3>NU.nl</h3>
						</div>
					</div>
					<div class="fragment" id="weer">
						<div class="top">
							<a class="preview" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=547">
								<i class="fas fa-search"></i>
							</a>
						</div>
						<a data-fancybox data-src="#weer-fragment" href="javascript:;" class="add-fragment"">
							<i class="fas fa-plus"></i><span>Toevoegen</span>
						</a>
						<div class="bottom">
							<h3>Weer</h3>
						</div>
					</div>
					<div class="fragment" id="l1">
						<div class="top">
							<a class="preview" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=553">
								<i class="fas fa-search"></i>
							</a>
						</div>
						<a data-fancybox data-src="#l1-fragment" href="javascript:;" class="add-fragment">
							<i class="fas fa-plus"></i><span>Toevoegen</span>
						</a>
						<div class="bottom">
							<h3>L1</h3>
						</div>
					</div>

					<div class="fragment" id="bitcoins">
						<div class="top">
							<a class="preview" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=411">
								<i class="fas fa-search"></i>
							</a>
						</div>
						<a data-fancybox data-src="#bitcoins-fragment" href="javascript:;" class="add-fragment">
							<i class="fas fa-plus"></i><span>Toevoegen</span>
						</a>
						<div class="bottom">
							<h3>Bitcoins</h3>
						</div>
					</div>

					<div class="fragment" id="busstation">
						<div class="top">
							<a class="preview" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=551">
								<i class="fas fa-search"></i>
							</a>
						</div>
						<a data-fancybox data-src="#busstation-fragment" href="javascript:;" class="add-fragment">
							<i class="fas fa-plus"></i><span>Toevoegen</span>
						</a>
						<div class="bottom">
							<h3>Bustijden</h3>
						</div>
					</div>

					<div class="fragment" id="verkeer">
						<div class="top">
							<a class="preview" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=546">
								<i class="fas fa-search"></i>
							</a>
						</div>
						<a data-fancybox data-src="#verkeer-fragment" href="javascript:;" class="add-fragment">
							<i class="fas fa-plus"></i><span>Toevoegen</span>
						</a>
						<div class="bottom">
							<h3>Verkeersinformatie</h3>
						</div>
					</div>

				</div>
			</div>

<!-- 			<div class="fragment-modal" id="custom-fragment" data-selectable="true">
				<div class="content-editor">
						<div class="left">
							<div class="intro">
								<h3>Maak hier je eigen fragment</h3>
								<p>Sleep eerst je layout naar het scherm en vul deze daarna met componenten.</p>
							</div>
							<div id="tabs">
							  <ul>
							    <li><a href="#tabs-1">Layout</a></li>
							    <li><a href="#tabs-2">Componenten</a></li>
							  </ul>
							  <div id="tabs-1">
							    <div class="element">
							    	<div class="col"></div>
							    </div>
							    <div class="element">
							    	<div class="col"></div>
							    	<div class="col"></div>
							    </div>
							    <div class="element">
							    	<div class="col"></div>
							    	<div class="col"></div>
							    	<div class="col"></div>
							    </div>
							    <div class="element">
							    	<div class="col"></div>
							    	<div class="col"></div>
							    	<div class="col"></div>
							    	<div class="col"></div>
							    </div>
							  </div>
							  <div id="tabs-2">
							    <div class="element">
							    	<i class="far fa-image"></i>
							    	<span>Afbeelding</span>
							    </div>
							    <div class="element">
							    	<i class="fas fa-video"></i>
							    	<span>Video</span>
							    </div>
							    <div class="element">
							    	<i class="fas fa-font"></i>
							    	<span>Tekst</span>
							    </div>
							  </div>
							</div>
						</div>
						<div class="right">
							<div class="form">
								<label>
									<p>Naam</p>
									<input type="text" placeholder="Naam fragment">
								</label>

								<label>
									<p>Duur</p>
									<input type="text" placeholder="Aantal seconden">					
								</label>

								<a href="#" class="my-fragments">
									Mijn fragmenten
								</a>
								<a href="#" class="save-fragments">
									Fragment opslaan
								</a>

							</div>
							<div class="content">
								<i class="fas fa-th-large"></i>
								<h3>Sleep hier je elementen naartoe</h3>
							</div>
							<div class="save">
								<label>
									<input type="submit" onclick="window.location.href='office.php'" value="Toevoegen">
								</label>
							</div>
						</div>
				</div>
			</div> -->

			<!-- NS POPUP -->

			<div class="fragment-modal" id="ns-fragment">
				<div class="content-modal">
					<div class="left">
						<h2>Fragment bewerken</h2>

						<label>
							<p>Naam</p>
							<input type="text" placeholder="Naam fragment">
						</label>

						<label>
							<p>Duur</p>
							<input type="text" placeholder="Aantal seconden">					
						</label>
						
						<label>
							<input type="submit" onclick="window.location.href='office.php'" value="Opslaan">
						</label>

					</div>
					<div class="right">
						<div class="preview">
							<img src="assets/images/screenshotNS.png" width="100%">
						</div>
					</div>
				</div>
			</div>

		<!-- Buienradar POPUP -->

		<div class="fragment-modal" id="buienradar-fragment">
			<div class="content-modal">
				<div class="left">
					<h2>Fragment bewerken</h2>

					<label>
						<p>Naam</p>
						<input type="text" placeholder="Naam fragment">
					</label>

					<label>
						<p>Duur</p>
						<input type="text" placeholder="Aantal seconden">					
					</label>
					
					<label>
						<input type="submit" onclick="window.location.href='office.php'" value="Opslaan">
					</label>

				</div>
				<div class="right">
					<div class="preview">
						<img src="assets/images/buienradar.png" width="100%">
					</div>
				</div>
			</div>
		</div>	

		<!-- BBC POPUP -->

		<div class="fragment-modal" id="bbc-fragment">
			<div class="content-modal">
				<div class="left">
					<h2>Fragment bewerken</h2>

					<label>
						<p>Naam</p>
						<input type="text" placeholder="Naam fragment">
					</label>

					<label>
						<p>Duur</p>
						<input type="text" placeholder="Aantal seconden">					
					</label>
					
					<label>
						<input type="submit" onclick="window.location.href='office.php'" value="Opslaan">
					</label>

				</div>
				<div class="right">
					<div class="preview">
						<img src="assets/images/bbc.png" width="100%">
					</div>
				</div>
			</div>
		</div>	

		<!-- NU.NL POPUP -->

		<div class="fragment-modal" id="nu-fragment">
			<div class="content-modal">
				<div class="left">
					<h2>Fragment bewerken</h2>

					<label>
						<p>Naam</p>
						<input type="text" placeholder="Naam fragment">
					</label>

					<label>
						<p>Duur</p>
						<input type="text" placeholder="Aantal seconden">					
					</label>
					
					<label>
						<input type="submit" onclick="window.location.href='office.php'" value="Opslaan">
					</label>

				</div>
				<div class="right">
					<div class="preview">
						<img src="assets/images/nu.png" width="100%">
					</div>
				</div>
			</div>
		</div>	

		<!-- WEER POPUP -->

		<div class="fragment-modal" id="weer-fragment">
			<div class="content-modal">
				<div class="left">
					<h2>Fragment bewerken</h2>

					<label>
						<p>Naam</p>
						<input type="text" placeholder="Naam fragment">
					</label>

					<label>
						<p>Duur</p>
						<input type="text" placeholder="Aantal seconden">					
					</label>
					
					<label>
						<input type="submit" onclick="window.location.href='office.php'" value="Opslaan">
					</label>

				</div>
				<div class="right">
					<div class="preview">
						<img src="assets/images/weer.png" width="100%">
					</div>
				</div>
			</div>
		</div>	

		<!-- L1 POPUP -->

		<div class="fragment-modal" id="l1-fragment">
			<div class="content-modal">
				<div class="left">
					<h2>Fragment bewerken</h2>

					<label>
						<p>Naam</p>
						<input type="text" placeholder="Naam fragment">
					</label>

					<label>
						<p>Duur</p>
						<input type="text" placeholder="Aantal seconden">					
					</label>
					
					<label>
						<input type="submit" onclick="window.location.href='office.php'" value="Opslaan">
					</label>

				</div>
				<div class="right">
					<div class="preview">
						<img src="assets/images/l1.png" width="100%">
					</div>
				</div>
			</div>
		</div>	

		<!-- BITCOINS POPUP -->

		<div class="fragment-modal" id="bitcoins-fragment">
			<div class="content-modal">
				<div class="left">
					<h2>Fragment bewerken</h2>

					<label>
						<p>Naam</p>
						<input type="text" placeholder="Naam fragment">
					</label>

					<label>
						<p>Duur</p>
						<input type="text" placeholder="Aantal seconden">					
					</label>
					
					<label>
						<input type="submit" onclick="window.location.href='office.php'" value="Opslaan">
					</label>

				</div>
				<div class="right">
					<div class="preview">
						<img src="assets/images/bitcoins.png" width="100%">
					</div>
				</div>
			</div>
		</div>	

		<!-- BUSSTATION POPUP -->

		<div class="fragment-modal" id="busstation-fragment">
			<div class="content-modal">
				<div class="left">
					<h2>Fragment bewerken</h2>

					<label>
						<p>Naam</p>
						<input type="text" placeholder="Naam fragment">
					</label>

					<label>
						<p>Duur</p>
						<input type="text" placeholder="Aantal seconden">					
					</label>
					
					<label>
						<input type="submit" onclick="window.location.href='office.php'" value="Opslaan">
					</label>

				</div>
				<div class="right">
					<div class="preview">
						<img src="assets/images/busstation.png" width="100%">
					</div>
				</div>
			</div>
		</div>

		<!-- VERKEERSINFORMATIE POPUP -->

		<div class="fragment-modal" id="verkeer-fragment">
			<div class="content-modal">
				<div class="left">
					<h2>Fragment bewerken</h2>

					<label>
						<p>Naam</p>
						<input type="text" placeholder="Naam fragment">
					</label>

					<label>
						<p>Duur</p>
						<input type="text" placeholder="Aantal seconden">					
					</label>
					
					<label>
						<input type="submit" onclick="window.location.href='office.php'" value="Opslaan">
					</label>

				</div>
				<div class="right">
					<div class="preview">
						<img src="assets/images/verkeersinformatie.png" width="100%">
					</div>
				</div>
			</div>
		</div>

		</main>	
	</div>

</body>
</html>