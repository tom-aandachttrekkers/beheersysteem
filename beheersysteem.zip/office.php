<?php include 'includes/header.php'; ?>
<body id="office">
	<?php include 'includes/sidebar.php'; ?>
	<div class="content">
		<div class="top">
			<div class="title">
				<i class="fas fa-list"></i>
				<h2>Afspeellijst Kantoor</h2>
			</div>
			<div class="account">
				<i class="far fa-user"></i>
				<span>Account</span>
			</div>
		</div>
		<div class="account-menu">
			<nav>
				<ul>
					<li><a href="handout_calamiteiten.pdf" target="_blank"><i class="fas fa-exclamation-triangle"></i>Calamiteiten</a></li>
					<li><a href="contact.php"><i class="fas fa-envelope"></i>Contact</a></li>
					<li class="logout"><a href="index.php"><i class="fas fa-sign-out-alt"></i>Uitloggen</a></li>
				</ul>
			</nav>
		</div>
		<main class="animsition">
			<div class="left">
				<div class="title">
					<h4>Afspeellijst bijwerken</h4>
				</div>
				<div class="new-playlist">
					<label>
						<p>Naam</p>
						<input type="text" placeholder="Naam afspeellijst" value="Kantoor">
					</label>
					<label class="screen-direction">
						<span class="sd active">Horizontaal<i class="fas fa-arrows-alt-h"></i></span><span class="sd">Verticaal<i class="fas fa-arrows-alt-v"></i></span>
					</label>
					<label>
						<p>Schermen</p>
						<select>
							<option>Selecteer scherm</option>
							<option>Scherm Kantoor</option>
						  	<option>Scherm Kantine</option>
						</select>
						<div class="current-screen">
							<span>Scherm Kantoor</span><span><i class="fas fa-trash-alt delete"></i></span>
						</div>
					</label>
					<label>
						<p>Frequentie</p>
						<select>
						  	<option>Dagelijks</option>
						  	<option>Wekelijks</option>
						  	<option>Specifieke datum</option>
						</select>

					</label>
					<label>
						<input type="submit" value="Bijwerken">
					</label>
				</div>
			</div>
			<div class="right">
				<div class="title">
					<h4>Fragmenten</h4>
				</div>
				<div class="playlist-drag">

					<div class="playlist">

						<div class="visable">
							<i class="fas fa-eye"></i>
						</div>

						<div class="show">
							<div class="preview-img" id="weather">
								<a class="preview-fragment" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=547">
									<i class="fas fa-search"></i>
								</a>
							</div>
							<div class="info">
								<p>Naam:</p>
								<h4>Weer Venray</h4>
							</div>
							<div class="duration">
								<p>Duur:</p>
								<h4>00:15</h4>
							</div>
							<div class="buttons">
								<a data-fancybox data-src="#ns-fragment" href="javascript:;" class="settings">
									<i class="fas fa-cog"></i>
								</a>
								<div class="trash">
									<i class="far fa-trash-alt"></i>
								</div>
							</div>
						</div>
					</div>

					<div class="playlist">

						<div class="visable">
							<i class="fas fa-eye"></i>
							
						</div>

						<div class="show">
							<div class="preview-img" id="buienradar">
								<a class="preview-fragment" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=550">
									<i class="fas fa-search"></i>
								</a>
							</div>
							<div class="info">
								<p>Naam:</p>
								<h4>Buienradar Nederland</h4>
							</div>
							<div class="duration">
								<p>Duur:</p>
								<h4>00:15</h4>
							</div>
							<div class="buttons">
								<a data-fancybox data-src="#ns-fragment" href="javascript:;" class="settings">
									<i class="fas fa-cog"></i>
								</a>
								<div class="trash">
									<i class="far fa-trash-alt"></i>
								</div>
							</div>
						</div>
					</div>

					<div class="playlist">

						<div class="visable">
							<i class="fas fa-eye"></i>
							
						</div>

						<div class="show">
							<div class="preview-img" id="verkeer">
								<a class="preview-fragment" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=550">
									<i class="fas fa-search"></i>
								</a>
							</div>
							<div class="info">
								<p>Naam:</p>
								<h4>Verkeer Nederland</h4>
							</div>
							<div class="duration">
								<p>Duur:</p>
								<h4>00:30</h4>
							</div>
							<div class="buttons">
								<a data-fancybox data-src="#ns-fragment" href="javascript:;" class="settings">
									<i class="fas fa-cog"></i>
								</a>
								<div class="trash">
									<i class="far fa-trash-alt"></i>
								</div>
							</div>
						</div>
					</div>

					<div class="playlist">

						<div class="visable">
							<i class="fas fa-eye"></i>
							
						</div>

						<div class="show">
							<div class="preview-img" id="bitcoins">
								<a class="preview-fragment" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=411">
									<i class="fas fa-search"></i>
								</a>
							</div>
							<div class="info">
								<p>Naam:</p>
								<h4>Koersen Bitcoins</h4>
							</div>
							<div class="duration">
								<p>Duur:</p>
								<h4>00:30</h4>
							</div>
							<div class="buttons">
								<a data-fancybox data-src="#ns-fragment" href="javascript:;" class="settings">
									<i class="fas fa-cog"></i>
								</a>
								<div class="trash">
									<i class="far fa-trash-alt"></i>
								</div>
							</div>
						</div>
					</div>

					<div class="playlist">

						<div class="visable">
							<i class="fas fa-eye"></i>
							
						</div>

						<div class="show">
							<div class="preview-img" id="nu">
								<a class="preview-fragment" href="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=552">
									<i class="fas fa-search"></i>
								</a>
							</div>
							<div class="info">
								<p>Naam:</p>
								<h4>NL Nieuws nu.nl</h4>
							</div>
							<div class="duration">
								<p>Duur:</p>
								<h4>00:30</h4>
							</div>
							<div class="buttons">
								<a data-fancybox data-src="#ns-fragment" href="javascript:;" class="settings">
									<i class="fas fa-cog"></i>
								</a>
								<div class="trash">
									<i class="far fa-trash-alt"></i>
								</div>
							</div>
						</div>
					</div>

				</div>
				<label>
					<a class="view-playlist screen-horizontal" href="http://www.prodiz.nl/v3/dev/client/index.php?pkey=7EC4402F">Afspeellijst bekijken</a>
					
				</label>
				<label>
					<input type="submit" class="add-fragment" onclick="window.location.href='fragment.php'" value="Fragment toevoegen">
				</label>
			</div>
		</main>	
	</div>

	<div class="fragment-modal" id="ns-fragment">
		<div class="content-modal">
			<div class="left">
				<h2>Fragment bewerken</h2>

				<label>
					<p>Naam</p>
					<input type="text" placeholder="Naam fragment">
				</label>

				<label>
					<p>Duur</p>
					<input type="text" placeholder="Aantal seconden">					
				</label>
				
				<label>
					<input type="submit" onclick="window.location.href='office.php'" value="Opslaan">
				</label>

			</div>
			<div class="right">
				
					<img src="assets/images/screenshotNS.png" width="100%">
				
			</div>
		</div>
	</div>

	<!-- POPUPS -->

	<div class="fragment-modal" id="view-playlist">
		<div class="content-modal">

			<div class="iframes">
				<div id="frame" class="iframe">
					<iframe src="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=555"></iframe>
				</div>
				<div id="frame1" class="iframe">
					<iframe src="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=552"></iframe>
				</div>
				<div id="frame2" class="iframe">
					<iframe src="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=550"></iframe>
				</div>
				<div id="frame3" class="iframe">
					<iframe src="http://www.prodiz.nl/v3/dev/client/preview-slide.php?id=553"></iframe>
				</div>
			</div>

<!-- 			<div class="playlist-iframe">
				<img class="imagepl active" src="assets/images/bbc.png">
				<img class="imagepl" src="assets/images/nu.png">
				<img class="imagepl" src="assets/images/buienradar.png">
				<img class="imagepl" src="assets/images/l1.png">
			</div> -->

		</div>
	</div>


</body>
</html>