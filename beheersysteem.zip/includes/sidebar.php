	
	<div class="sidebar">
		<a href="dashboard.php" class="logo">
			<img src="assets/images/logo.png">
		</a>
		<nav>
			<ul id="navmenu">
				<li><a href="dashboard.php" ><i class="fas fa-tachometer-alt"></i>Dashboard</a></li>
				<li><a href="playlists.php"><i class="fas fa-list"></i>Afspeellijsten</a></li>
				<li class="playlist-nav"><a href="office.php">Kantoor</a></li>
				<li class="playlist-nav"><a href="canteen.php">Kantine</a></li>
			</ul>
		</nav>
	</div>