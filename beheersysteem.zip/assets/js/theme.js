

    $(document).ready(function () {    
    //Get CurrentUrl variable by combining origin with pathname, this ensures that any url appendings (e.g. ?RecordId=100) are removed from the URL
    var CurrentUrl = window.location.origin+window.location.pathname;
    //Check which menu item is 'active' and adjust apply 'active' class so the item gets highlighted in the menu
    //Loop over each <a> element of the NavMenu container
    $('#navmenu a').each(function(Key,Value)
        {
            //Check if the current url
            if(Value['href'] === CurrentUrl)
            {
                //We have a match, add the 'active' class to the parent item (li element).
                $(Value).parent().addClass('active');
            }
        });



    // TABS

    $( function() {
      $( "#tabs" ).tabs();
    } );

    // ACCOUNT MENU

    $( ".account" ).click(function() {
      $(".account-menu").toggle();
    });

    $('.preview').fancybox({

        'type': 'iframe'

    });

    $('.preview-fragment').fancybox({

        'type': 'iframe'

    });

    $(function() {
       $(".sd").click(function() {
          // remove classes from all
          $(".sd").removeClass("active");
          // add class to the one we clicked
          $(this).addClass("active");
       });
    });

        $('a.screen-horizontal').fancybox({
            type: "iframe",
            iframe : {
               tpl : '<iframe id="fancybox-frame{rnd}" name="fancybox-frame{rnd}" class="fancybox-iframe frame-horizontal" frameborder="0" vspace="0" hspace="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen allowtransparency="true" src="http://www.prodiz.nl/v3/dev/client/index.php?pkey=7EC4402F"></iframe>'
            }
        });

        $('a.screen-vertical').fancybox({
            type: "iframe",
            iframe : {
               tpl : '<iframe id="fancybox-frame{rnd}" name="fancybox-frame{rnd}" class="fancybox-iframe frame-vertical" frameborder="0" vspace="0" hspace="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen allowtransparency="true" src=""></iframe>'
            }
        });



    // PAGE TRANSITIONS

    $(".animsition").animsition({
      inClass: 'fade-in',
      outClass: 'fade-out',
      inDuration: 1500,
      outDuration: 800,
      linkElement: '.animsition-link',
      // e.g. linkElement: 'a:not([target="_blank"]):not([href^="#"])'
      loading: true,
      loadingParentElement: 'body', //animsition wrapper element
      loadingClass: 'animsition-loading',
      loadingInner: '', // e.g '<img src="loading.svg" />'
      timeout: false,
      timeoutCountdown: 5000,
      onLoadEvent: true,
      browser: [ 'animation-duration', '-webkit-animation-duration'],
      // "browser" option allows you to disable the "animsition" in case the css property in the array is not supported by your browser.
      // The default setting is to disable the "animsition" in a browser that does not support "animation-duration".
      overlay : false,
      overlayClass : 'animsition-overlay-slide',
      overlayParentElement : 'body',
      transition: function(url){ window.location.href = url; }
    });

    // REMOVE PLAYLIST

    $("#remove-office").click(function(){
        $("#office-playlist").remove();
    });

    $("#remove-canteen").click(function(){
        $("#canteen-playlist").remove();
    });

    // SORTABLE JQUERY

    $( function() {
      $( ".playlist-drag" ).sortable({
        placeholder: "ui-state-highlight",
        axis: "y"
      });
      $( ".playlist-drag" ).disableSelection();
    } );

    // HIDE / SHOW FRAGMENT

    $( ".visable" ).click(function() {
      $(this).parent().find('.show').toggleClass("hide");
      $(this).find('i').toggleClass('fa-eye fa-eye-slash')
      // $(this).toggleClass("show-hide");
    });
 
    $( ".trash" ).click(function() {
      $(this).parent().parent().parent().remove();
    });

    $( ".delete" ).click(function() {
      $(this).parent().parent().remove();
    });

    // jQuery(function () {
    //     var $box1 = $('div[id^=frame]'),
    //         i = 0,
    //         len = $box1.length;

    //     $box1.slice(1).hide();
    //     setInterval(function () {
    //         $box1.eq(i).fadeOut(function () {
    //             i = (i + 1) % len
    //             $box1.eq(i).fadeIn();
    //         })
    //     }, 10000)
    // })

    // jQuery(function () {
    //     var $els = $('div[id^=frame]'),
    //         i = 0,
    //         len = $els.length;

    //     var arr = $(".imagepl");
    //   var current = 1;

    //     $els.slice(1).hide();
    //     setInterval(function () {
    //         $els.eq(i).fadeOut(function () {
    //             i = (i + 1) % len
    //             $els.eq(i).fadeIn();

    //              if (arr.length > 0){
    //             //Remove class of all items
    //             arr.removeClass("active");
    //             //Set Class of current item
    //             arr.eq(current).addClass("active");     
    //             //Increase the current index
    //             current = (current + 1) % arr.length;
    //           }


    //         })

    //     }, 10000)
    // })

 });


