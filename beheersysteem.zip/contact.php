<?php include 'includes/header.php'; ?>
<body id="contact">
	<?php include 'includes/sidebar.php'; ?>
	<div class="content">
		<div class="top">
			<div class="title">
				<i class="fas fa-envelope"></i>
				<h2>Contact</h2>
			</div>
			<div class="account">
				<i class="far fa-user"></i>
				<span>Account</span>
			</div>
		</div>
		<div class="account-menu">
			<nav>
				<ul>
					<li><a href="handout_calamiteiten.pdf" target="_blank"><i class="fas fa-exclamation-triangle"></i>Calamiteiten</a></li>
					<li><a href="contact.php"><i class="fas fa-envelope"></i>Contact</a></li>
					<li class="logout"><a href="index.php"><i class="fas fa-sign-out-alt"></i>Uitloggen</a></li>
				</ul>
			</nav>
		</div>
		<main class="animsition">
			<div class="contact">
				
				<div class="info">
					<img src="assets/images/logo-aandachttrekkers.png" alt="">
					<a><i class="fas fa-phone"></i>+31(0)478 517430</a>
					<a href="mailto:info@aandachttrekkers.nl"><i class="fas fa-envelope"></i>info@aandachttrekkers.nl</span>
				</div>
			</div>
		</main>	
	</div>



</body>
</html>