<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Login</title>
	<link rel="stylesheet" href="assets/css/theme.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="assets/js/jquery.fancybox.js"></script>
	<script src="assets/js/theme.js"></script>
	<script src="assets/js/animation.js"></script>
</head>
<body id="login" class="animsition">
	
		<div class="login">
			<img src="assets/images/logo-prodiz.png">
			<input type="text" placeholder="Gebruikersnaam">
			<input type="password" placeholder="Wachtwoord">
			<input type="submit" onclick="window.location.href='dashboard.php'" value="Inloggen">
		</div>
	
</body>
</html>