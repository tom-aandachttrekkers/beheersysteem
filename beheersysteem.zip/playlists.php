<?php include 'includes/header.php'; ?>
<body id="playlists">
	<?php include 'includes/sidebar.php'; ?>
	<div class="content">
		<div class="top">
			<div class="title">
				<i class="fas fa-list"></i>
				<h2>Afspeellijsten</h2>
			</div>
			<div class="account">
				<i class="far fa-user"></i>
				<span>Account</span>
			</div>
		</div>
		<div class="account-menu">
			<nav>
				<ul>
					<li><a href="handout_calamiteiten.pdf" target="_blank"><i class="fas fa-exclamation-triangle"></i>Calamiteiten</a></li>
					<li><a href="contact.php"><i class="fas fa-envelope"></i>Contact</a></li>
					<li class="logout"><a href="index.php"><i class="fas fa-sign-out-alt"></i>Uitloggen</a></li>
				</ul>
			</nav>
		</div>
		<main class="animsition">
			<div class="left">
				<div class="title">
					<h4>Nieuwe afspeellijst</h4>
				</div>
				<div class="new-playlist">
					<label>
						<p>Naam</p>
						<input type="text" placeholder="Naam afspeellijst">
					</label>
					<label class="screen-direction">
						<span class="sd active">Horizontaal<i class="fas fa-arrows-alt-h"></i></span><span class="sd">Verticaal<i class="fas fa-arrows-alt-v"></i></span>
					</label>
					<label>
						<p>Schermen</p>
						<select>
						 	<option class="placeholder" disabled selected value> Selecteer scherm</option>
						  <option>Scherm Kantine</option>
						  <option>Scherm Kantoor</option>
						</select>
					</label>
					<label>
						<p>Frequentie</p>
						<select>
						 	<option class="placeholder" disabled selected value> Selecteer frequentie</option>
						  <option>Dagelijks</option>
						  <option>Wekelijks</option>
						  <option>Specifieke datum</option>

						</select>

					</label>
					<label>
						<input type="submit" onclick="window.location.href='fragment.php'" value="Afspeellijst toevoegen">
					</label>
				</div>
			</div>
			<div class="right">
				<div class="title">
					<h4>Huidige afspeellijsten</h4>
				</div>
				<div class="current-playlist">
					<div class="playlist" id="office-playlist">
						<div class="preview-img">
							<a class="play screen-horizontal" href="http://www.prodiz.nl/v3/dev/client/index.php?pkey=7EC4402F">
								<i class="fas fa-play"></i>
							</a>
							<div class="direction">
								<i class="fas fa-arrows-alt-h"></i>
							</div>
							<span>Afspeellijst Kantoor</span>
						</div>
						<div class="info">
							<p>Frequentie</p>
							<h4>Dagelijks</h4>
							<p>Items / Lengte</p>
							<h4>2 / 00:20</h4>
							<p>Schermen</p>
							<h4>Scherm kantoor</h4>
						</div>
						<div class="buttons">
							<a href="office.php" class="settings">
								<i class="fas fa-cog"></i>
							</a>
							<div class="trash" id="remove-office">
								<i class="far fa-trash-alt"></i>
							</div>
						</div>
					</div>
					<div class="playlist" id="canteen-playlist">
						<div class="preview-img">
							<a class="play screen-horizontal" href="http://www.prodiz.nl/v3/dev/client/index.php?pkey=7EC4402F">
								<i class="fas fa-play"></i>
							</a>
							<div class="direction">
								<i class="fas fa-arrows-alt-h"></i>
							</div>
							<span>Afspeellijst Kantine</span>
						</div>
						<div class="info">
							<p>Frequentie</p>
							<h4>Dagelijks</h4>
							<p>Items / Lengte</p>
							<h4>4 / 00:50</h4>
							<p>Schermen</p>
							<h4>Scherm Kantine</h4>
						</div>
						<div class="buttons">
							<a href="canteen.php" class="settings">
								<i class="fas fa-cog"></i>
							</a>
							<div class="trash" id="remove-canteen">
								<i class="far fa-trash-alt"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>	
	</div>
</body>
</html>