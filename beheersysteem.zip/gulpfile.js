var gulp    = require('gulp'),
    sass    = require('gulp-sass')
    notify  = require('gulp-notify')
    concat  = require('gulp-concat');

gulp.task('sass', function() {

    gulp.src('assets/sass/*.scss')
        .pipe(sass())
        .pipe(gulp.dest('assets/css'))
        .pipe(notify('Sass compiled!'));

});

gulp.task('js', function() {

    gulp
        .src([
            'node_modules/jquery/dist/jquery.min.js',
            'node_modules/bootstrap-sass/assets/javascripts/bootstrap.min.js'
        ])
        .pipe(concat('jquery-bootstrap.min.js'))
        .pipe(gulp.dest('assets/js/'));

});

gulp.task('copy', function() {

    gulp
        .src([
            'node_modules/font-awesome/fonts/**/*.{ttf,svg,eot,woff,woff2}',
            'node_modules/bootstrap-sass/assets/fonts/**/*.{ttf,svg,eot,woff,woff2}'
        ])
        .pipe(gulp.dest('assets/fonts'));

});

gulp.task('watch', function(){

    gulp.watch('assets/sass/**/*.scss', ['sass']);

});

gulp.task('default', ['sass', 'js', 'copy']);