<?php include 'includes/header.php'; ?>

<body id="dashboard">
	<?php include 'includes/sidebar.php'; ?>
	<div class="content">
		<div class="top">
			<div class="title">
				<i class="fas fa-tachometer-alt"></i>
				<h2>Dashboard</h2>
			</div>
			<div class="account">
				<i class="far fa-user"></i>
				<span>Account</span>
			</div>
		</div>
		<div class="account-menu">
			<nav>
				<ul>
					<li><a href="handout_calamiteiten.pdf" target="_blank"><i class="fas fa-exclamation-triangle"></i>Calamiteiten</a></li>
					<li><a href="contact.php"><i class="fas fa-envelope"></i>Contact</a></li>
					<li class="logout"><a href="index.php"><i class="fas fa-sign-out-alt"></i>Uitloggen</a></li>
				</ul>
			</nav>
		</div>
		<main class="animsition">
			<div class="left">
				<div class="playlists">
					<div class="title">
						<h4>Huidige afspeellijsten</h4>
					</div>
					<div class="all-playlists">
						<a href="office.php" class="playlist">
							<h5>Kantoor</h5>
							<span>bekijk <i class="fas fa-angle-right"></i></span>
						</a>
						<a href="canteen.php" class="playlist">
							<h5>Kantine</h5>
							<span>bekijk <i class="fas fa-angle-right"></i></span>
						</a>
					</div>
				</div>
			</div>
			<div class="right">

<!-- <a href="playlists.php"></a> -->

				<div class="make-playlist">
					<a href="playlists.php">
					<div class="mp-title">
						<h4>Maak een afspeellijst</h4>
						<h6>Vul onze templates met jouw eigen tekst en media</h6>
					</div>
					<div class="arrow">
						<i class="fas fa-angle-right"></i>
					</div>
					</a>
				</div>

				<div class="screens">
					<div class="title">
						<h4>Huidige schermen</h4>

						<label>
							<p>Locatie</p>
							<select>
						 		<option class="placeholder" disabled selected value> Selecteer locatie</option>
							  <option>Horst</option>
							  <option>Venlo</option>
							</select>
						</label>

					</div>	
					<div class="current-screens">

						<a class="screen-horizontal" href="http://www.prodiz.nl/v2/wiertz/client/index.php?pkey=9DA9933B">
							<i class="fas fa-arrows-alt-h"></i>
							<h4>Horst - Video wall</h4>
						</a>


						<a class="screen-vertical" href="http://www.prodiz.nl/v2/wiertz/client/index.php?pkey=4CB68484">
							<i class="fas fa-arrows-alt-v"></i>
							<h4>Horst - Vacatures</h4>
						</a>


					</div>



				</div>
			</div>
		</main>	
	</div>

</body>
</html>